import uuid
from database import get_connection

sessions = {}  # token -> username

def register_user(username, password):
    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)",
                       (username, password))
        conn.commit()
        return {"message": "User registered successfully"}
    except:
        return {"error": "Username already exists"}
    finally:
        conn.close()

def login_user(username, password):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE username=? AND password=?",
                   (username, password))
    user = cursor.fetchone()
    conn.close()

    if user:
        token = str(uuid.uuid4())
        sessions[token] = username
        return {"access_token": token}
    else:
        return {"error": "Invalid credentials"}

def verify_token(token):
    return sessions.get(token)
