import requests
import websocket
import threading
import json

SERVER_URL = "http://127.0.0.1:8000"

def receive(ws):
    while True:
        try:
            message = ws.recv()
            print(message)
        except:
            break

def main():
    print("1. Register")
    print("2. Login")
    choice = input("Choose option: ")

    username = input("Username: ")
    password = input("Password: ")

    if choice == "1":
        r = requests.post(f"{SERVER_URL}/register",
                          json={"username": username, "password": password})
        print(r.json())

    r = requests.post(f"{SERVER_URL}/login",
                      json={"username": username, "password": password})
    data = r.json()

    if "access_token" not in data:
        print("Login failed")
        return

    token = data["access_token"]

    ws = websocket.WebSocket()
    ws.connect(f"ws://127.0.0.1:8000/ws?token={token}")

    threading.Thread(target=receive, args=(ws,), daemon=True).start()

    while True:
        msg = input()
        ws.send(msg)

if __name__ == "__main__":
    main()
