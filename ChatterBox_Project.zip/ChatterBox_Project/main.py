from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
import sqlite3
import uuid
import json
from datetime import datetime

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Database
conn = sqlite3.connect("database.db", check_same_thread=False)
cursor = conn.cursor()

# USERS TABLE
cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
    username TEXT PRIMARY KEY,
    password TEXT,
    warnings INTEGER DEFAULT 0,
    blocked INTEGER DEFAULT 0
)
""")

# MESSAGES TABLE
cursor.execute("""
CREATE TABLE IF NOT EXISTS messages(
    id TEXT PRIMARY KEY,
    sender TEXT,
    message TEXT,
    timestamp TEXT,
    seen INTEGER DEFAULT 0
)
""")

conn.commit()

active_connections = {}

STOP_WORDS = ["badword", "hate", "stupid"]

@app.get("/")
def home():
    return RedirectResponse("/login")

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
def register(username: str = Form(...), password: str = Form(...)):
    try:
        cursor.execute("INSERT INTO users(username,password) VALUES (?,?)", (username, password))
        conn.commit()
        return RedirectResponse("/login", status_code=302)
    except:
        return {"error": "User already exists"}

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    cursor.execute("SELECT password, blocked FROM users WHERE username=?", (username,))
    user = cursor.fetchone()

    if user and user[0] == password:
        if user[1] == 1:
            return {"error": "You are blocked"}

        response = RedirectResponse("/chat", status_code=302)
        response.set_cookie("username", username)
        return response

    return {"error": "Invalid credentials"}

@app.get("/chat", response_class=HTMLResponse)
def chat(request: Request):
    username = request.cookies.get("username")
    if not username:
        return RedirectResponse("/login")

    return templates.TemplateResponse("chat.html", {
        "request": request,
        "username": username
    })

@app.get("/messages")
def get_messages():
    cursor.execute("SELECT * FROM messages ORDER BY timestamp")
    rows = cursor.fetchall()

    return [
        {
            "id": r[0],
            "sender": r[1],
            "message": r[2],
            "timestamp": r[3],
            "seen": r[4]
        } for r in rows
    ]

@app.websocket("/ws/{username}")
async def websocket_endpoint(websocket: WebSocket, username: str):
    await websocket.accept()
    active_connections[username] = websocket

    try:
        while True:
            data = json.loads(await websocket.receive_text())

            # MESSAGE
            if data["type"] == "message":

                cursor.execute("SELECT warnings, blocked FROM users WHERE username=?", (username,))
                user = cursor.fetchone()

                if user[1] == 1:
                    await websocket.send_text(json.dumps({"type": "blocked"}))
                    continue

                message_text = data["message"].lower()

                if any(word in message_text for word in STOP_WORDS):
                    warnings = user[0] + 1

                    if warnings >= 3:
                        cursor.execute("UPDATE users SET blocked=1 WHERE username=?", (username,))
                        conn.commit()
                        await websocket.send_text(json.dumps({"type": "blocked"}))
                        continue
                    else:
                        cursor.execute("UPDATE users SET warnings=? WHERE username=?", (warnings, username))
                        conn.commit()
                        await websocket.send_text(json.dumps({
                            "type": "warning",
                            "count": warnings
                        }))
                        continue

                message_id = str(uuid.uuid4())
                timestamp = datetime.now().isoformat()

                cursor.execute(
                    "INSERT INTO messages VALUES (?,?,?,?,?)",
                    (message_id, username, data["message"], timestamp, 0)
                )
                conn.commit()

                message_data = {
                    "type": "message",
                    "id": message_id,
                    "sender": username,
                    "message": data["message"],
                    "timestamp": timestamp,
                    "seen": 0
                }

                for connection in active_connections.values():
                    await connection.send_text(json.dumps(message_data))

            # SEEN
            if data["type"] == "seen":

                cursor.execute("SELECT sender FROM messages WHERE id=?", (data["message_id"],))
                result = cursor.fetchone()

                if result:
                    sender = result[0]

                    cursor.execute(
                        "UPDATE messages SET seen=1 WHERE id=?",
                        (data["message_id"],)
                    )
                    conn.commit()

                    if sender in active_connections:
                        await active_connections[sender].send_text(
                            json.dumps({
                                "type": "seen",
                                "message_id": data["message_id"]
                            })
                        )

    except WebSocketDisconnect:
        if username in active_connections:
            del active_connections[username]



