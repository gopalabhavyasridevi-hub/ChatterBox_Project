from database import get_connection
from datetime import datetime

def save_message(user_id, username, content):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO messages (user_id, username, content, timestamp)
        VALUES (?, ?, ?, ?)
    """, (user_id, username, content,
          datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")))

    conn.commit()
    conn.close()

def get_recent_messages(limit=20):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT username, content, timestamp
        FROM messages
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))

    rows = cursor.fetchall()
    conn.close()

    # Reverse so oldest appears first
    return rows[::-1]
